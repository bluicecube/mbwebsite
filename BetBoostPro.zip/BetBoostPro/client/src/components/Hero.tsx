import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ArrowRight, Zap, Bot, TrendingUp } from "lucide-react";

export default function Hero() {
  const { toast } = useToast();

  return (
    <section className="py-20 md:py-28 bg-background relative overflow-hidden">
      {/* Abstract decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute -top-20 -right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 -left-40 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-20 right-1/3 w-64 h-64 bg-indigo-600/5 rounded-full blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <div className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full mb-6">
              <Zap className="w-4 h-4 text-primary mr-2" />
              <span className="text-sm font-medium text-primary">Smart Automated Matched Betting</span>
            </div>
            <h1 className="font-bold text-4xl md:text-5xl lg:text-6xl leading-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-400">
              Earn Consistent Profits on Autopilot
            </h1>
            <p className="text-lg md:text-xl text-foreground/80 mb-8 max-w-lg">
              Make £500-£1,000 in your first month and approximately £500 monthly thereafter. 
              Our AI-powered system handles everything — you just collect the profits.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button 
                onClick={() => document.getElementById('signup')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
                className="bg-primary hover:bg-primary/90 text-white py-6 px-8 rounded-lg font-medium"
              >
                Get Started Today <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
                variant="outline"
                className="border-primary/20 text-primary hover:bg-primary hover:text-white py-6 px-8 rounded-lg font-medium"
              >
                See How It Works
              </Button>
            </div>
            <div className="mt-10 grid grid-cols-2 gap-4">
              <div className="flex items-center">
                <div className="p-2 bg-primary/10 rounded-lg mr-3">
                  <Bot className="w-5 h-5 text-primary" />
                </div>
                <div className="text-sm text-foreground/80">
                  <span className="font-semibold block text-foreground">100% Automated</span>
                  No manual work required
                </div>
              </div>
              <div className="flex items-center">
                <div className="p-2 bg-primary/10 rounded-lg mr-3">
                  <TrendingUp className="w-5 h-5 text-primary" />
                </div>
                <div className="text-sm text-foreground/80">
                  <span className="font-semibold block text-foreground">1,200+ Users</span>
                  Earning consistent profits
                </div>
              </div>
            </div>
          </div>
          <div className="md:w-1/2">
            <div className="bg-gradient-to-r from-primary/10 to-blue-500/10 rounded-2xl p-1">
              <div className="relative backdrop-blur-sm bg-background/30 rounded-xl overflow-hidden border border-white/10 p-6">
                <div className="absolute -top-20 -right-20 w-56 h-56 bg-primary/20 rounded-full blur-3xl z-0"></div>
                
                {/* Modern data visualization */}
                <div className="relative z-10 pt-4">
                  {/* Dashboard Header */}
                  <div className="flex justify-between items-center mb-6">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                        <TrendingUp className="w-5 h-5 text-primary" />
                      </div>
                      <div className="ml-3">
                        <h3 className="font-bold text-lg text-foreground">AutoBetPro Dashboard</h3>
                        <p className="text-sm text-foreground/60">Live Profit Tracking</p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      <div className="w-3 h-3 rounded-full bg-primary/40"></div>
                      <div className="w-3 h-3 rounded-full bg-primary/40"></div>
                    </div>
                  </div>
                  
                  {/* Profit Stats */}
                  <div className="grid grid-cols-3 gap-4 mb-8">
                    <div className="bg-background/40 backdrop-blur-sm border border-white/10 rounded-lg p-4">
                      <p className="text-sm text-foreground/60 mb-1">Today's Profit</p>
                      <p className="text-xl font-bold text-primary">£143.28</p>
                    </div>
                    <div className="bg-background/40 backdrop-blur-sm border border-white/10 rounded-lg p-4">
                      <p className="text-sm text-foreground/60 mb-1">Weekly Profit</p>
                      <p className="text-xl font-bold text-primary">£657.92</p>
                    </div>
                    <div className="bg-background/40 backdrop-blur-sm border border-white/10 rounded-lg p-4">
                      <p className="text-sm text-foreground/60 mb-1">Total Profit</p>
                      <p className="text-xl font-bold text-primary">£3,472.58</p>
                    </div>
                  </div>
                  
                  {/* Chart Visualization */}
                  <div className="bg-background/40 backdrop-blur-sm border border-white/10 rounded-lg p-4 mb-6">
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="font-medium text-foreground">Profit Growth</h4>
                      <div className="flex items-center space-x-2 text-sm">
                        <span className="w-3 h-3 bg-primary inline-block rounded-full"></span>
                        <span className="text-foreground/60">Your Profit</span>
                      </div>
                    </div>
                    
                    {/* SVG Chart */}
                    <div className="h-36 w-full">
                      <svg className="w-full h-full" viewBox="0 0 300 100">
                        {/* Grid Lines */}
                        <line x1="0" y1="20" x2="300" y2="20" stroke="#e5e7eb" strokeWidth="1" strokeDasharray="4" />
                        <line x1="0" y1="40" x2="300" y2="40" stroke="#e5e7eb" strokeWidth="1" strokeDasharray="4" />
                        <line x1="0" y1="60" x2="300" y2="60" stroke="#e5e7eb" strokeWidth="1" strokeDasharray="4" />
                        <line x1="0" y1="80" x2="300" y2="80" stroke="#e5e7eb" strokeWidth="1" strokeDasharray="4" />
                        
                        {/* Chart line */}
                        <path 
                          d="M0,80 C20,70 40,65 60,55 C80,45 100,40 120,35 C140,30 160,25 180,30 C200,35 220,25 240,15 C260,10 280,5 300,10" 
                          fill="none" 
                          stroke="#2E3192" 
                          strokeWidth="2"
                        />
                        
                        {/* Gradient Under Line */}
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" stopColor="#2E3192" stopOpacity="0.3" />
                          <stop offset="100%" stopColor="#2E3192" stopOpacity="0" />
                        </linearGradient>
                        <path 
                          d="M0,80 C20,70 40,65 60,55 C80,45 100,40 120,35 C140,30 160,25 180,30 C200,35 220,25 240,15 C260,10 280,5 300,10 L300,100 L0,100 Z" 
                          fill="url(#gradient)" 
                        />
                        
                        {/* Data Points */}
                        <circle cx="0" cy="80" r="3" fill="#2E3192" />
                        <circle cx="60" cy="55" r="3" fill="#2E3192" />
                        <circle cx="120" cy="35" r="3" fill="#2E3192" />
                        <circle cx="180" cy="30" r="3" fill="#2E3192" />
                        <circle cx="240" cy="15" r="3" fill="#2E3192" />
                        <circle cx="300" cy="10" r="3" fill="#2E3192" />
                        
                        {/* Current point highlight */}
                        <circle cx="300" cy="10" r="5" fill="white" stroke="#2E3192" strokeWidth="2" />
                      </svg>
                    </div>
                    
                    {/* Chart Labels */}
                    <div className="flex justify-between text-xs text-foreground/60 pt-2">
                      <span>Jan</span>
                      <span>Feb</span>
                      <span>Mar</span>
                      <span>Apr</span>
                      <span>May</span>
                      <span>Jun</span>
                    </div>
                  </div>
                  
                  {/* Action Bar */}
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium text-foreground/70">Your earnings</p>
                      <p className="text-2xl font-bold text-primary">£1,736.29</p>
                    </div>
                    <Button size="sm" className="bg-primary text-white">Open Dashboard</Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
