import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Lock, CreditCard } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "Member since 2022",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&h=100&q=80",
    text: "I was skeptical at first, but AutoBetPro has completely changed my financial situation. I made over £800 in my first month, and I've been consistently earning around £500 every month since. The automation makes it so easy!",
    rating: 5,
  },
  {
    name: "Michael Thompson",
    role: "Member since 2021",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=100&h=100&q=80",
    text: "As someone who works full-time, I never thought I'd have time for matched betting. With AutoBetPro, the system does everything for me. I've made over £6,000 in the past year with minimal effort on my part.",
    rating: 5,
  },
  {
    name: "Emily Wilson",
    role: "Member since 2023",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=100&h=100&q=80",
    text: "The customer service at AutoBetPro is exceptional. Whenever I've had a question, they've responded quickly and thoroughly. The platform is intuitive, and I've been able to earn extra money each month to pay off my student loans.",
    rating: 4.5,
  },
];

const trustBadges = [
  {
    icon: <Shield className="h-6 w-6 text-primary" />,
    text: "SSL Secured",
  },
  {
    icon: <Lock className="h-6 w-6 text-primary" />,
    text: "Data Protection Compliant",
  },
  {
    icon: <CreditCard className="h-6 w-6 text-primary" />,
    text: "Secure Payments",
  },
];

export default function Testimonials() {
  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    return (
      <div className="flex text-secondary">
        {[...Array(fullStars)].map((_, i) => (
          <svg key={i} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
            <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
          </svg>
        ))}
        
        {hasHalfStar && (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
            <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
          </svg>
        )}
      </div>
    );
  };

  return (
    <section id="testimonials" className="py-16 md:py-24 bg-accent">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-[ClashDisplay] font-bold text-3xl md:text-4xl text-primary mb-4">
            What Our Users Say
          </h2>
          <p className="text-lg text-foreground max-w-2xl mx-auto">
            Join thousands of satisfied customers who are earning consistent profits with AutoBetPro.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card 
              key={index} 
              className="bg-white shadow-md hover:shadow-lg transition-shadow duration-300 hover:-translate-y-1 transform transition-transform"
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name} 
                    className="w-14 h-14 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-bold text-primary">{testimonial.name}</h4>
                    <p className="text-sm text-foreground/70">{testimonial.role}</p>
                  </div>
                </div>
                <div className="mb-4">
                  {renderStars(testimonial.rating)}
                </div>
                <p className="text-foreground">{testimonial.text}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-16">
          <Card className="bg-white shadow-md">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 mb-6 md:mb-0">
                  <h3 className="font-[ClashDisplay] font-bold text-2xl text-primary mb-4">
                    Trusted by UK Bettors
                  </h3>
                  <div className="flex flex-wrap gap-4 mb-6">
                    <Badge variant="secondary" className="bg-accent py-2 px-4 rounded-lg">
                      <span className="font-medium text-primary">£2.3M+ Profits Generated</span>
                    </Badge>
                    <Badge variant="secondary" className="bg-accent py-2 px-4 rounded-lg">
                      <span className="font-medium text-primary">1,200+ Active Users</span>
                    </Badge>
                    <Badge variant="secondary" className="bg-accent py-2 px-4 rounded-lg">
                      <span className="font-medium text-primary">4.8/5 Average Rating</span>
                    </Badge>
                  </div>
                  <p className="text-foreground">
                    Join our community of successful matched bettors who are generating consistent tax-free income every month.
                  </p>
                </div>
                <div className="md:w-1/2 md:pl-8">
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
                    {trustBadges.map((badge, index) => (
                      <div key={index} className="bg-accent p-4 rounded-xl flex items-center justify-center w-48 h-20">
                        <div className="text-center">
                          {badge.icon}
                          <div className="text-sm font-medium mt-1">{badge.text}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
