import { Card, CardContent } from "@/components/ui/card";
import { 
  Cpu, 
  LineChart, 
  ShieldCheck, 
  Headphones, 
  BookOpen, 
  Calendar 
} from "lucide-react";

const features = [
  {
    icon: <Cpu />,
    title: "AI-Powered Automation",
    description: "Our system handles everything from finding opportunities to placing bets automatically. You don't need to lift a finger."
  },
  {
    icon: <LineChart />,
    title: "Real-time Analytics",
    description: "Track your earnings and performance with our intuitive dashboard showing all your bets, profits, and growth over time."
  },
  {
    icon: <ShieldCheck />,
    title: "Zero-Risk Strategy",
    description: "Our mathematical approach exploits bookmaker promotions and guarantees profits by covering all possible outcomes."
  },
  {
    icon: <Headphones />,
    title: "Community Support",
    description: "Join our community of matched bettors who share strategies, tips, and help each other maximize earnings."
  },
  {
    icon: <BookOpen />,
    title: "Knowledge Base",
    description: "Access our comprehensive guides and resources to understand the matched betting process and optimize your approach."
  },
  {
    icon: <Calendar />,
    title: "Continuous Opportunities",
    description: "Our system constantly scans for new promotions across all bookmakers to ensure you never miss a profitable bet."
  }
];

export default function Features() {
  return (
    <section id="features" className="py-20 md:py-28 relative">
      {/* Abstract background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full mb-4">
            <span className="text-sm font-medium text-primary">Cutting-edge Features</span>
          </div>
          <h2 className="font-bold text-3xl md:text-4xl bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-400 mb-4">
            Why Choose AutoBetPro?
          </h2>
          <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
            Our platform combines cutting-edge technology with proven matched betting strategies to deliver consistent profits with zero effort.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="bg-background/30 border border-primary/10 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 transform"
            >
              <CardContent className="p-8">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-primary to-blue-500 mb-6 text-white">
                  {feature.icon}
                </div>
                <h3 className="font-bold text-xl mb-3 text-foreground">
                  {feature.title}
                </h3>
                <p className="text-foreground/70">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
