import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, UserPlus, Settings, PlayCircle, LineChart } from "lucide-react";

const steps = [
  {
    number: 1,
    icon: <UserPlus className="w-7 h-7" />,
    title: "Create Account",
    description: "Sign up in seconds with your email. No credit card or personal details required."
  },
  {
    number: 2,
    icon: <Settings className="w-7 h-7" />,
    title: "Set Preferences",
    description: "Configure your betting accounts, risk level, and stake size based on your budget."
  },
  {
    number: 3,
    icon: <PlayCircle className="w-7 h-7" />,
    title: "Activate System",
    description: "Turn on our AI-powered platform to automatically identify and place matched bets."
  },
  {
    number: 4,
    icon: <LineChart className="w-7 h-7" />,
    title: "Collect Profits",
    description: "Monitor your growing earnings and withdraw your profits anytime you want."
  }
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 md:py-28 bg-gradient-to-b from-background to-background/40 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute top-1/2 -right-20 w-80 h-80 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 left-20 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full mb-4">
            <span className="text-sm font-medium text-primary">Simple 4-Step Process</span>
          </div>
          <h2 className="font-bold text-3xl md:text-4xl bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-400 mb-4">
            How AutoBetPro Works
          </h2>
          <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
            Our streamlined process makes matched betting completely automated and hassle-free.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {steps.map((step) => (
            <div key={step.number} className="relative">
              <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-primary/20 to-blue-400/20 z-0">
                <div className="absolute top-0 left-0 h-full bg-gradient-to-r from-primary to-blue-400" style={{ width: `${(step.number / steps.length) * 100}%` }}></div>
              </div>
              <Card className="bg-background/30 border border-primary/10 backdrop-blur-sm shadow-lg mt-6 relative">
                <CardContent className="p-8">
                  <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-12 h-12 rounded-full bg-gradient-to-r from-primary to-blue-500 flex items-center justify-center text-white shadow-lg">
                    {step.icon}
                  </div>
                  <div className="pt-6">
                    <span className="inline-block bg-primary/10 text-primary text-xs font-semibold px-2 py-1 rounded mb-3">Step {step.number}</span>
                    <h3 className="font-bold text-xl mb-3 text-foreground">
                      {step.title}
                    </h3>
                    <p className="text-foreground/70">{step.description}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
        
        <div className="mt-20">
          <Card className="bg-background/30 border border-primary/10 backdrop-blur-sm shadow-lg overflow-hidden">
            <CardContent className="p-0">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-8 md:p-12 flex flex-col justify-center">
                  <div className="inline-flex items-center px-3 py-1 bg-primary/10 rounded-full mb-4 w-fit">
                    <span className="text-xs font-medium text-primary">See It In Action</span>
                  </div>
                  <h3 className="font-bold text-2xl md:text-3xl text-foreground mb-4">
                    Watch How Easy It Is
                  </h3>
                  <p className="text-foreground/70 mb-6">
                    Our system automatically identifies opportunities, calculates optimal stakes, and places bets on your behalf - all while you relax and watch the profits grow.
                  </p>
                  <Button 
                    className="bg-primary hover:bg-primary/90 text-white w-fit"
                  >
                    Watch Demo <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
                <div className="relative">
                  {/* Gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-blue-500/20 mix-blend-overlay z-10"></div>
                  <img 
                    src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&h=675&q=80" 
                    alt="AutoBetPro platform dashboard" 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-20 h-20 bg-primary/90 backdrop-blur-sm rounded-full flex items-center justify-center cursor-pointer">
                      <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
