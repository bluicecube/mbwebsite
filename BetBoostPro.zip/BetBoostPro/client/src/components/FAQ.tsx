import { useState } from "react";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { HelpCircle, ArrowRight } from "lucide-react";

const faqs = [
  {
    question: "What is matched betting?",
    answer: "Matched betting is a technique that uses bookmaker free bets and promotions to guarantee profits regardless of the outcome. It's a mathematical approach to betting that eliminates the risk of gambling by covering all possible outcomes of an event. It's completely legal and is considered a form of tax-free income in the UK."
  },
  {
    question: "Is matched betting legal?",
    answer: "Yes, matched betting is completely legal in the UK. It's simply a way of using mathematics to ensure you profit from bookmaker promotions. Many mainstream publications like The Guardian and The Telegraph have written about matched betting as a legitimate way to earn extra income."
  },
  {
    question: "How much money do I need to start?",
    answer: "We recommend starting with at least £200 to maximize your initial profits. This allows you to take advantage of multiple bookmaker offers simultaneously. However, you can start with as little as £50 and build your bankroll over time."
  },
  {
    question: "How does the automation work?",
    answer: "Our AI-powered software continuously scans bookmakers for promotions and calculates the optimal bets to place. Once you've set up your preferences and connected your betting accounts, the system will automatically place bets for you, ensuring you always make a profit regardless of the outcome."
  },
  {
    question: "Do I need betting experience?",
    answer: "No prior betting experience is required. Our system is designed to be user-friendly and handles all the complex calculations and bet placements for you. We also provide comprehensive guides and tutorials to help you understand the process."
  },
  {
    question: "Is there any cost to use the service?",
    answer: "No, our automated matched betting service is completely free to use. We believe in creating a fair system where everyone can benefit from this proven money-making strategy without any upfront costs or subscription fees."
  }
];

export default function FAQ() {
  return (
    <section id="faq" className="py-20 md:py-28 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-background to-background/40"></div>
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute top-1/3 right-1/4 w-80 h-80 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full mb-4">
            <HelpCircle className="w-4 h-4 text-primary mr-2" />
            <span className="text-sm font-medium text-primary">Common Questions</span>
          </div>
          <h2 className="font-bold text-3xl md:text-4xl bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-400 mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
            Everything you need to know about our automated matched betting service.
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <Accordion type="single" collapsible className="space-y-6">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-background/30 backdrop-blur-sm border border-primary/10 rounded-xl shadow-lg overflow-hidden"
              >
                <AccordionTrigger className="p-6 text-lg font-medium text-foreground hover:text-primary transition-colors">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 text-foreground/80 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
        
        <div className="mt-16 text-center bg-gradient-to-r from-primary/10 to-blue-500/10 backdrop-blur-sm p-8 rounded-xl border border-primary/10 max-w-2xl mx-auto">
          <h3 className="text-xl font-bold text-foreground mb-3">Still have questions?</h3>
          <p className="text-foreground/80 mb-6">Our team is here to help you make the most of your matched betting journey.</p>
          <Button className="bg-primary hover:bg-primary/90 text-white font-medium px-6 py-6">
            Contact Support <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
      </div>
    </section>
  );
}
