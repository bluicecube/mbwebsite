import { Card, CardContent } from "@/components/ui/card";
import { PoundSterling, Calendar, Bot } from "lucide-react";

export default function Stats() {
  return (
    <section className="py-16 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-blue-500/5 backdrop-blur-3xl"></div>
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="bg-background/30 border border-primary/10 shadow-lg backdrop-blur-sm overflow-hidden">
            <CardContent className="p-8">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-foreground/70">First Month</h3>
                <div className="p-2 bg-primary/10 rounded-lg">
                  <PoundSterling className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div className="text-4xl font-bold text-primary mb-2">
                £500-£1,000
              </div>
              <p className="text-foreground/70">Average initial earnings</p>
              <div className="mt-4 w-full h-1 bg-primary/10 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-primary to-blue-400 w-[85%]"></div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-background/30 border border-primary/10 shadow-lg backdrop-blur-sm overflow-hidden">
            <CardContent className="p-8">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-foreground/70">Monthly</h3>
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div className="text-4xl font-bold text-primary mb-2">
                £500
              </div>
              <p className="text-foreground/70">Recurring monthly profit</p>
              <div className="mt-4 w-full h-1 bg-primary/10 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-primary to-blue-400 w-[70%]"></div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-background/30 border border-primary/10 shadow-lg backdrop-blur-sm overflow-hidden">
            <CardContent className="p-8">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-foreground/70">Automation</h3>
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Bot className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div className="text-4xl font-bold text-primary mb-2">
                100%
              </div>
              <p className="text-foreground/70">Fully autonomous system</p>
              <div className="mt-4 w-full h-1 bg-primary/10 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-primary to-blue-400 w-[100%]"></div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
