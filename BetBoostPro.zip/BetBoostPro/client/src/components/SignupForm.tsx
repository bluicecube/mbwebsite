import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Rocket, Zap, ArrowRight } from "lucide-react";

const formSchema = z.object({
  fullName: z.string().min(2, "Full name is required"),
  email: z.string().email("Please enter a valid email address"),
  termsAgreed: z.boolean().refine(val => val === true, {
    message: "You must agree to the terms and conditions",
  }),
});

type FormValues = z.infer<typeof formSchema>;

export default function SignupForm() {
  const { toast } = useToast();
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      email: "",
      termsAgreed: false,
    },
  });

  const mutation = useMutation({
    mutationFn: (data: FormValues) => 
      apiRequest("POST", "/api/leads", data),
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "You're all set! We'll get you started right away.",
      });
      reset();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit the form. Please try again.",
      });
    },
  });

  const onSubmit = (data: FormValues) => {
    // Submit the form data directly
    mutation.mutate(data);
  };

  return (
    <section id="signup" className="py-20 md:py-28 relative overflow-hidden">
      {/* Abstract background */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/10 to-blue-600/5"></div>
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute -top-20 left-1/4 w-96 h-96 bg-blue-400/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-primary/5 rounded-full blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full mb-4">
            <Rocket className="w-4 h-4 text-primary mr-2" />
            <span className="text-sm font-medium text-primary">Start Earning Today</span>
          </div>
          <h2 className="font-bold text-3xl md:text-4xl bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-400 mb-6">
            Start Earning Automated Profits Today
          </h2>
          <p className="text-lg text-foreground/80 mb-8 max-w-2xl mx-auto">
            Join thousands of users who are already making consistent passive income through our advanced matched betting system.
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
            <div className="bg-background/40 backdrop-blur-sm border border-primary/10 rounded-xl p-5 shadow-lg">
              <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-r from-primary to-blue-500 rounded-full mx-auto mb-3">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div className="text-2xl font-bold text-primary mb-1">£500-£1,000</div>
              <p className="text-foreground/70 text-sm">First month earnings</p>
            </div>
            <div className="bg-background/40 backdrop-blur-sm border border-primary/10 rounded-xl p-5 shadow-lg">
              <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-r from-primary to-blue-500 rounded-full mx-auto mb-3">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div className="text-2xl font-bold text-primary mb-1">£500</div>
              <p className="text-foreground/70 text-sm">Monthly thereafter</p>
            </div>
            <div className="bg-background/40 backdrop-blur-sm border border-primary/10 rounded-xl p-5 shadow-lg">
              <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-r from-primary to-blue-500 rounded-full mx-auto mb-3">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div className="text-2xl font-bold text-primary mb-1">Equal Split</div>
              <p className="text-foreground/70 text-sm">Fair earnings model</p>
            </div>
          </div>
        </div>
        
        <Card className="bg-background/40 backdrop-blur-sm border border-primary/10 rounded-xl shadow-xl max-w-md mx-auto overflow-hidden">
          <div className="h-2 bg-gradient-to-r from-primary to-blue-500"></div>
          <CardContent className="p-8 pt-6">
            <h3 className="font-bold text-xl text-foreground mb-6 text-center">
              Create Your Account
            </h3>
            
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              <div>
                <Label htmlFor="fullName" className="text-foreground/80 text-sm font-medium mb-1.5 block">
                  Full Name
                </Label>
                <Input
                  id="fullName"
                  className={`w-full bg-background/60 border-primary/20 focus:border-primary focus:ring-primary ${errors.fullName ? "border-red-500" : ""}`}
                  placeholder="Enter your full name"
                  {...register("fullName")}
                />
                {errors.fullName && (
                  <p className="text-red-500 text-sm mt-1">{errors.fullName.message}</p>
                )}
              </div>
              
              <div>
                <Label htmlFor="email" className="text-foreground/80 text-sm font-medium mb-1.5 block">
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  className={`w-full bg-background/60 border-primary/20 focus:border-primary focus:ring-primary ${errors.email ? "border-red-500" : ""}`}
                  placeholder="Enter your email"
                  {...register("email")}
                />
                {errors.email && (
                  <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>
                )}
              </div>
              
              <div className="flex items-start space-x-2">
                <Checkbox
                  id="termsAgreed"
                  className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                  {...register("termsAgreed")}
                />
                <div className="grid gap-1.5 leading-none">
                  <Label
                    htmlFor="termsAgreed"
                    className={`text-sm leading-relaxed ${
                      errors.termsAgreed ? "text-red-500" : "text-foreground/80"
                    }`}
                  >
                    I agree to the{" "}
                    <a href="#" className="text-primary hover:underline font-medium">
                      Terms of Service
                    </a>{" "}
                    and{" "}
                    <a href="#" className="text-primary hover:underline font-medium">
                      Privacy Policy
                    </a>
                  </Label>
                  {errors.termsAgreed && (
                    <p className="text-red-500 text-xs">{errors.termsAgreed.message}</p>
                  )}
                </div>
              </div>
              
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-primary to-blue-500 hover:opacity-90 text-white font-medium py-6 mt-2"
                disabled={mutation.isPending}
              >
                {mutation.isPending ? "Processing..." : "Start Earning Today"} 
                {!mutation.isPending && <ArrowRight className="ml-2 w-5 h-5" />}
              </Button>
            </form>
            
            <div className="mt-6 text-center text-sm text-foreground/70">
              <p>No credit card required. Equal earnings split.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
