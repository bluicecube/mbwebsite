import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X } from "lucide-react";

const plans = [
  {
    name: "Starter",
    description: "Perfect for beginners",
    price: "£29",
    period: "/month",
    features: [
      { included: true, text: "Automated matched betting system" },
      { included: true, text: "Access to basic promotions" },
      { included: true, text: "Email support" },
      { included: true, text: "Profit tracking dashboard" },
      { included: false, text: "Advanced automation features" },
      { included: false, text: "Priority customer support" },
    ],
    popular: false,
  },
  {
    name: "Professional",
    description: "For serious matched bettors",
    price: "£49",
    period: "/month",
    features: [
      { included: true, text: "Everything in Starter" },
      { included: true, text: "Advanced automation features" },
      { included: true, text: "Access to all promotions" },
      { included: true, text: "Priority email & chat support" },
      { included: true, text: "Enhanced profit optimization" },
      { included: false, text: "Dedicated account manager" },
    ],
    popular: true,
  },
  {
    name: "Premium",
    description: "Maximum earnings potential",
    price: "£79",
    period: "/month",
    features: [
      { included: true, text: "Everything in Professional" },
      { included: true, text: "Dedicated account manager" },
      { included: true, text: "VIP access to high-value offers" },
      { included: true, text: "Phone support" },
      { included: true, text: "Multi-account management" },
      { included: true, text: "Advanced profit strategies" },
    ],
    popular: false,
  },
];

export default function Pricing() {
  return (
    <section id="pricing" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-[ClashDisplay] font-bold text-3xl md:text-4xl text-primary mb-4">
            Pricing Plans
          </h2>
          <p className="text-lg text-foreground max-w-2xl mx-auto">
            Choose the plan that fits your matched betting goals and start earning today.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative ${
                plan.popular 
                  ? "border-2 border-primary scale-105 z-10 shadow-xl" 
                  : "border-2 border-accent shadow-md"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 right-0 left-0 mx-auto w-max">
                  <Badge className="bg-secondary hover:bg-secondary/90 py-1 px-4 rounded-full text-white">
                    Most Popular
                  </Badge>
                </div>
              )}
              <CardContent className="p-8">
                <div className="mb-6">
                  <h3 className="font-[ClashDisplay] font-bold text-2xl text-primary">{plan.name}</h3>
                  <p className="text-foreground mt-2">{plan.description}</p>
                  <div className="mt-4">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    <span className="text-foreground">{plan.period}</span>
                  </div>
                </div>
                
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start">
                      {feature.included ? (
                        <Check className="h-5 w-5 text-secondary shrink-0 mt-0.5 mr-2" />
                      ) : (
                        <X className="h-5 w-5 text-destructive shrink-0 mt-0.5 mr-2" />
                      )}
                      <span className={feature.included ? "text-foreground" : "text-foreground/60"}>
                        {feature.text}
                      </span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  onClick={() => document.getElementById('signup')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
                  className={`w-full ${
                    plan.popular 
                      ? "bg-primary hover:bg-primary/90 text-white" 
                      : "bg-accent hover:bg-primary hover:text-white text-primary"
                  }`}
                >
                  Get Started
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-foreground">All plans come with a 14-day money-back guarantee. No questions asked.</p>
        </div>
      </div>
    </section>
  );
}
