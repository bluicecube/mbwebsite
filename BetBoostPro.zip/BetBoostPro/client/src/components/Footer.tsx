import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Mail, 
  Phone, 
  MapPin 
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-foreground py-12 text-white">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-[ClashDisplay] font-bold text-xl mb-4">AutoBetPro</h3>
            <p className="mb-4">
              The UK's leading automated matched betting service helping thousands earn consistent profits.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-secondary transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-white hover:text-secondary transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-white hover:text-secondary transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white hover:text-secondary transition-colors">
                <Linkedin size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="#features" className="hover:text-secondary transition-colors">Features</a>
              </li>
              <li>
                <a href="#how-it-works" className="hover:text-secondary transition-colors">How It Works</a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-secondary transition-colors">Pricing</a>
              </li>
              <li>
                <a href="#testimonials" className="hover:text-secondary transition-colors">Testimonials</a>
              </li>
              <li>
                <a href="#faq" className="hover:text-secondary transition-colors">FAQ</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Legal</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="hover:text-secondary transition-colors">Terms of Service</a>
              </li>
              <li>
                <a href="#" className="hover:text-secondary transition-colors">Privacy Policy</a>
              </li>
              <li>
                <a href="#" className="hover:text-secondary transition-colors">Cookie Policy</a>
              </li>
              <li>
                <a href="#" className="hover:text-secondary transition-colors">GDPR Compliance</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold mb-4">Contact Us</h4>
            <ul className="space-y-2">
              <li className="flex items-start">
                <Mail className="h-5 w-5 mr-2 mt-0.5" />
                <span>support@autobetpro.co.uk</span>
              </li>
              <li className="flex items-start">
                <Phone className="h-5 w-5 mr-2 mt-0.5" />
                <span>+44 20 1234 5678</span>
              </li>
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 mt-0.5" />
                <span>123 Finance Street, London, UK</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/20 text-center md:text-left">
          <div className="md:flex md:justify-between md:items-center">
            <p>&copy; {new Date().getFullYear()} AutoBetPro Ltd. All rights reserved.</p>
            <div className="mt-4 md:mt-0">
              <div className="h-10 bg-foreground/80 text-white px-4 py-2 rounded inline-flex items-center">
                Secure Payment Methods Accepted
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
