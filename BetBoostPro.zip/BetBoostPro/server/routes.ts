import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertLeadSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  
  // Lead capture endpoint
  app.post("/api/leads", async (req: Request, res: Response) => {
    try {
      // Validate lead data
      const result = insertLeadSchema.safeParse(req.body);
      
      if (!result.success) {
        const validationError = fromZodError(result.error);
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: validationError.message 
        });
      }

      // Check if email already exists
      const leads = await storage.getAllLeads();
      const existingLead = leads.find(lead => lead.email === result.data.email);
      if (existingLead) {
        return res.status(409).json({ message: "Email already registered" });
      }

      // Store the lead
      const lead = await storage.createLead(result.data);
      return res.status(201).json({ message: "Lead captured successfully", lead });
    } catch (error) {
      console.error("Error capturing lead:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all leads (for admin purposes)
  app.get("/api/leads", async (req: Request, res: Response) => {
    try {
      const leads = await storage.getAllLeads();
      return res.status(200).json(leads);
    } catch (error) {
      console.error("Error fetching leads:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
